#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 5298c703
#   function = ensure_access_etc_motd_configured
#   applicable =
# # END METADATA
#
#
#
#
# CIS-LBK _Main Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_access_etc_motd_configured.sh
#
# Name                 Date        Description
# ------------------------------------------------------------------------------------------------
# J Brown              04/03/24    Recommendation "Ensure access to /etc/motd is configured"
#

ensure_access_etc_motd_configured()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# If either the UID or GID is not correct, set the variable l_uid to "failed".  We will fix both of them even if one is already correct.
	ensure_access_etc_motd_configured_chk()
	{
		# Checks for correctly set permissions and ownership
		echo "- Start check - Ensure access to /etc/motd is configured" | tee -a "$LOG" 2>> "$ELOG"
        l_output="" l_output2=""

		for l_file in "/etc/motd"; do
            if [ -f "$l_file" ]; then
                if stat -Lc "%a" "$l_file" | grep -Pq '^\h*[0-6][0-4][0-4]$'; then
                    l_output="$l_output\n  Permissions on \"$l_file\" are \"$(stat -c "%a" "$l_file")\""
                else
                    l_output2="$l_output2\n  Permissions on \"$l_file\" are \"$(stat -c "%a" "$l_file")\""
                fi

                if stat -Lc "%u:%g" "$l_file" | grep -Pq '^\h*0:0$'; then
                    l_output="  $l_output\n  \"$l_file\" is owned by \"$(stat -c "%U" "$l_file")\" and belongs to group \"$(stat -c "%G" "$l_file")\""
                else
                    l_output2="  $l_output2\n  \"$l_file\" is owned by \"$(stat -c "%U" "$l_file")\" and belongs to group \"$(stat -c "%G" "$l_file")\""
                fi
            else
                l_output="$l_output\n  \"$l_file\" does not exist on the system"
            fi
        done

		if [ -z "$l_output2" ]; then
            echo -e "- PASSED:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure access to /etc/motd is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAILED:\n- Failing Values:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
            if [ -n "$l_output" ]; then
                echo -e "- Passing Values:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            fi
            echo -e "- End check - Ensure access to /etc/motd is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-102}"
        fi
	}

	ensure_access_etc_motd_configured_fix()
	{
		echo "- Start remediation - Ensure access to /etc/motd is configured" | tee -a "$LOG" 2>> "$ELOG"

        for l_file in "/etc/motd"; do
            if [ -f "$l_file" ]; then
                if ! stat -Lc "%a" "$l_file" | grep -Pq '^\h*[0-6][0-4][0-4]$'; then
                    echo -e "- Setting permissions on $l_file" | tee -a "$LOG" 2>> "$ELOG"
					chmod u-x,go-wx "$(readlink -e "$l_file")"
                fi

                if ! stat -Lc "%u:%g" "$l_file" | grep -Pq '^\h*0:0$'; then
                    echo -e "- Setting ownership on $l_file" | tee -a "$LOG" 2>> "$ELOG"
					chown root:root "$(readlink -e "$l_file")"
                fi
            fi
        done

        echo "- End remediation - Ensure access to /etc/motd is configured" | tee -a "$LOG" 2>> "$ELOG"
	}

	ensure_access_etc_motd_configured_chk
	if [ $? -eq 101 ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		if [ "$l_test" != "NA" ]; then
			ensure_access_etc_motd_configured_fix
			if [ "$l_test" != "manual" ]; then
				ensure_access_etc_motd_configured_chk
				if [ $? -eq 101 ]; then
					[ "$l_test" != "failed" ] && l_test="remediated"
				else
					l_test="failed"
				fi
			fi
		fi
	fi

	# Set return code and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac

}