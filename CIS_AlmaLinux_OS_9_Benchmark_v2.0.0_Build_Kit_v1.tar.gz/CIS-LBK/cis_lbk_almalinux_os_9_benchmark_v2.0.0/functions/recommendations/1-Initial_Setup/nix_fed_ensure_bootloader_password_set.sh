#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 1cf88ffa
#   function = fed_ensure_bootloader_password_set
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_bootloader_password_set.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/16/20    Recommendation "Ensure bootloader password is set"
# Justin Brown       10/29/22    Updated to modern format and used check script from benchmark
# David Neilson      04/13/24    Modified to satisfy benchmarks for Fed-19,28,34.  Does not reference grub.cfg.  For Fedora 34 and beyond, does not check EFI directory.

fed_ensure_bootloader_password_set()
{
   echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
   l_test=""
   
   fed_ensure_bootloader_password_set_chk()
	{
        echo -e "- Start check - Ensure bootloader password is set" | tee -a "$LOG" 2>> "$ELOG"
        l_tst1="" l_tst2="" l_output="" 
      
        l_efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT') 
        l_gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*') 
      
        # The benchmark for Fedora 34 (and presumably beyond) does not reference the EFI directory
        if grep -P -- '^\h*PRETTY_NAME=' /etc/os-release | grep -Piq -- 'Linux [^12]' && [ -f "$l_gbdir"/grub.cfg ]; then 
            l_grubdir="$l_gbdir" && l_grubfile="$l_gbdir/grub.cfg"
        elif [ -f "$l_efidir"/grub.cfg ]; then 
            l_grubdir="$l_efidir" && l_grubfile="$l_efidir/grub.cfg" 
        elif [ -f "$l_gbdir"/grub.cfg ]; then 
            l_grubdir="$l_gbdir" && l_grubfile="$l_gbdir/grub.cfg" 
        fi
        
        l_userfile="$l_grubdir/user.cfg" 

        if awk -F. '/^\s*GRUB2_PASSWORD/ {print $1"."$2"."$3}' $l_userfile | grep -Piq -- '^\h*GRUB2_PASSWORD=grub.pbkdf2.sha512\h*\b'; then
            l_output="- bootloader password set in \"$l_userfile\""
        fi     
         
        if [ -n "$l_output" ]; then
			echo -e "- PASS:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure bootloader password is set" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL:\n- bootloader password is NOT set" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure bootloader password is set" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi 
    }
   
    fed_ensure_bootloader_password_set_fix()
    {
   
      echo -e "- Start remediation - Ensure bootloader password is set" | tee -a "$LOG" 2>> "$ELOG"      
      
      echo -e "- Set a bootloader password.\n- For newer grub2 based systems (Release 7.2 and newer), create an encrypted password with grub2-setpassword :\n    # grub2-setpassword\n    Enter password: <password>\n    Confirm password: <password>" | tee -a "$LOG" 2>> "$ELOG"   
      l_test="manual"
      
      echo -e "- End remediation - Ensure bootloader password is set" | tee -a "$LOG" 2>> "$ELOG"
    }
   
    fed_ensure_bootloader_password_set_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
        if [ "$l_test" != "NA" ]; then
            fed_ensure_bootloader_password_set_fix
            if [ "$l_test" != "manual" ]; then
                fed_ensure_bootloader_password_set_chk
            fi
        fi
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}