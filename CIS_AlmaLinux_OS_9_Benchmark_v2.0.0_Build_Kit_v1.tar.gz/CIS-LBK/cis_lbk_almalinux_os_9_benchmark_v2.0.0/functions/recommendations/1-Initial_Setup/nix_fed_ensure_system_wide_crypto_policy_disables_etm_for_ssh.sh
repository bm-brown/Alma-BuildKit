#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 310abc09
#   function = fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh
#   applicable =
# # END METADATA
#
#
#
#
#
#
#
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh.sh
#
# 
# Name              Date        Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus        06/17/24    Recommendation "Ensure system wide crypto policy disables EtM for ssh"

fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh_chk()
    {
        echo -e "- Start check - Ensure system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
        l_output=""

        # Verify EtM is disabled    
        if grep -Pi -- '^\h*etm(@\S+)?\h*=\h*([^#\n\r]+)?DISABLE_ETM\b' /etc/crypto-policies/state/CURRENT.pol; then
            echo -e "- System wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            l_output="passed"
        else
            echo -e "- System wide crypto policy ALLOWS EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            l_output="failed"    
        fi

        if [ "$l_output" = "passed" ]; then
            echo -e "- PASS: system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAIL: system wide crypto policy enables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}" 
        fi       
    }

    fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh_fix()
    {
        echo -e "- Start remediation - Ensure system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"

        # Create NO-SSHETM.pmod
        echo -e "- Creating NO-SSHETM.pmod" | tee -a "$LOG" 2>> "$ELOG"
        echo -e "# This is a subpolicy to disable EtM for ssh\netm@SSH = DISABLE_ETM" >> /etc/crypto-policies/policies/modules/NO-SSHETM.pmod

        # Update the crypto policy
        update-crypto-policies --set DEFAULT:NO-SHA1:NO-WEAKMAC:NO-SSHCBC:NO-SSHCHACHA20:NO-SSHETM

        echo "- Reboot required for cryptographic settings to be effective" | tee -a "$LOG" 2>> "$ELOG"
        l_test="manual"

        echo -e "- End remediation - Ensure system wide crypto policy disables EtM for ssh" | tee -a "$LOG" 2>> "$ELOG"

    }

    fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh_chk
    if [ "$?" = "101" ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh_fix
        if [ "$l_test" != "manual" ]; then
            fed_ensure_system_wide_crypto_policy_disables_etm_for_ssh_chk
        fi
    fi   

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	         
}