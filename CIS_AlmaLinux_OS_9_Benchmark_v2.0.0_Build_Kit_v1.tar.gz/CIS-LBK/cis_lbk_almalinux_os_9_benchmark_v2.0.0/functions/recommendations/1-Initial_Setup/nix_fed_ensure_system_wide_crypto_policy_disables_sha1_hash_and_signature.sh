#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = ebef721e
#   function = fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature.sh
# 
# Name              Date        Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar      10/03/23    Recommendation "Ensure system wide crypto policy disables sha1 hash and signature support"
#

fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"

    fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature_chk()
    {
        echo -e "- Start check - Ensure system wide crypto policy disables sha1 hash and signature support" | tee -a "$LOG" 2>> "$ELOG"
        l_test=""
        l_output=""

        # Check for 'hash' or 'sign' with '-sha1' in /etc/crypto-policies/state/CURRENT.pol
        if grep -Pi -- '^\h*(hash|sign)\h*=\h*([^\n\r#]+)?-sha1\b' /etc/crypto-policies/state/CURRENT.pol; then
            l_output="- System wide crypto policy does NOT disable sha1 hash and signature support" && l_test="failed"
        else
            # Check for 'sha1_in_certs = 0' in /etc/crypto-policies/state/CURRENT.pol
            if grep -Pi -- '^\h*sha1_in_certs\h*=\h*0' /etc/crypto-policies/state/CURRENT.pol; then
                l_output="$l_output\n - System wide crypto policy disables sha1 hash and signature support" && l_test="passed"
            else
                l_output="$l_output\n - System wide crypto policy does NOT disable sha1 hash and signature support" && l_test="failed"
            fi
        fi

        if [ "$l_test" = "passed" ]; then
            echo -e "- PASS:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables sha1 hash and signature support" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAIL:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure system wide crypto policy disables sha1 hash and signature support" | tee -a "$LOG" 2>> "$ELOG"
        fi
    }

    fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature_fix()
    {
        echo -e "- Start remediation - Ensure system wide crypto policy disables sha1 hash and signature support" | tee -a "$LOG" 2>> "$ELOG"

        # Create NO-SHA1.pmod
        echo -e "- Creating NO-SHA1.pmod" | tee -a "$LOG" 2>> "$ELOG"
        echo -e "# This is a subpolicy dropping the SHA1 hash and signature support\nhash = -SHA1\nsign = -*-SHA1\nsha1_in_certs = 0" > /etc/crypto-policies/policies/modules/NO-SHA1.pmod

        # Set the default crypto policy to use NO-SHA1.pmod
        update-crypto-policies --set DEFAULT:NO-SHA1

        echo "- Reboot required for cryptographic settings to be effective" | tee -a "$LOG" 2>> "$ELOG"
        l_test="manual"

        echo -e "- End remediation - Ensure system-wide crypto policy disables SHA1 hash and signature support" | tee -a "$LOG" 2>> "$ELOG"
    }

    fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature_chk
    if [ "$?" = "101" ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature_fix
        if [ "$l_test" != "manual" ]; then
            fed_ensure_system_wide_crypto_policy_disables_sha1_hash_and_signature_chk
        fi
    fi

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	
}
