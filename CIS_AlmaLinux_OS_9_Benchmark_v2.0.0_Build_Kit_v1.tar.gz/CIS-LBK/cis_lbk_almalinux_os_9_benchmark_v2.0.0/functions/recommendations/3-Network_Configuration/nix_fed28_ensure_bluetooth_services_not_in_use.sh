#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 550af80b
#   function = fed28_ensure_bluetooth_services_not_in_use
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommednation Function
# ~/CIS-LBK/functions/recommendations/nix_fed28_ensure_bluetooth_services_not_in_use.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar      08/28/23     Recommendation "Ensure bluetooth services are not in use"
#

fed28_ensure_bluetooth_services_not_in_use()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	
	fed28_ensure_bluetooth_services_not_in_use_chk()
	{
		l_output="" l_output2=""

		echo "- Start check - Ensure bluetooth is services are not in use" | tee -a "$LOG" 2>> "$ELOG"
		
		if systemctl is-enabled bluetooth.service 2>/dev/null | grep '^enabled'; then
            l_output2="$l_output2\n- \"bluetooth.service\" appears to be enabled"
        else
            l_output="$l_output\n- \"bluetooth.service\" does NOT appear to be enabled"
        fi

        if systemctl is-active bluetooth.service 2>/dev/null | grep '^active'; then
            l_output2="$l_output2\n- \"bluetooth.service\" appears to be active"
        else
            l_output="$l_output\n- \"bluetooth.service\" does NOT appear to be active"
        fi
		
		if [ -z "$l_output2" ]; then 
			echo -e "\n- Audit Result:\n  ** PASS **\n - * Correctly configured * :\n$l_output\n"
			echo -e "- End check - Ensure bluetooth is services are not in use" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "\n- Audit Result:\n  ** FAIL **\n - * Reasons for audit failure * :\n$l_output2\n"
            [ -n "$l_output" ] && echo -e "- * Correctly configured * :\n$l_output\n"
			echo -e "- End check - Ensure bluetooth is services are not in use" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi

	}

	fed28_ensure_bluetooth_services_not_in_use_fix()
	{
		echo -e "- Start remediation - Ensure bluetooth is services are not in use" | tee -a "$LOG" 2>> "$ELOG"

		if systemctl is-active bluetooth.service 2>/dev/null | grep '^active'; then
            echo -e "- Stopping bluetooth.service" | tee -a "$LOG" 2>> "$ELOG"
		    systemctl stop bluetooth.service
        fi

        if systemctl is-enabled bluetooth.service 2>/dev/null | grep '^enabled'; then
            echo -e "- Masking bluetooth.service" | tee -a "$LOG" 2>> "$ELOG"
		    systemctl mask bluetooth.service
        fi

		echo -e "- End remediation - Ensure bluetooth is services are not in use" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed28_ensure_bluetooth_services_not_in_use_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed28_ensure_bluetooth_services_not_in_use_fix
		if [ "$l_test" != "manual" ]; then
			fed28_ensure_bluetooth_services_not_in_use_chk
			if [ "$?" = "101" ]; then
				[ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}