#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = e29594b5
#   function = fed28_ensure_nftables_loopback_traffic_is_configured
#   applicable =
# # END METADATA
#

#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed28_ensure_nftables_loopback_traffic_is_configured.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Justin Brown       06/30/22    Recommendation "Ensure nftables loopback traffic is configured"
# Randie Bejar		 11/08/23 	 Updated to new version Ensure host based firewall loopback traffic is configured

fed28_ensure_nftables_loopback_traffic_is_configured()
{
	# Start recommendation entirely for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed28_ensure_nftables_loopback_traffic_is_configured_chk()
	{
		echo "- Start check - Ensure nftables loopback traffic is configured" | tee -a "$LOG" 2>> "$ELOG"
		l_nft_test="" l_ipsaddr_test="" l_ip6saddr_test="" failed_results=""

		if nft list ruleset | awk '/hook\s+input\s+/,/\}\s*(#.*)?$/' | grep -Pq -- '\H+\h+"lo"\h+accept'; then
			l_nft_test="passed"
		else
			l_nft_test="$l_nft_test\n - Network traffic to the loopback address is not set to accept"
		fi

		l_ipsaddr="$(nft list ruleset | awk '/filter_IN_public_deny|hook\s+input\s+/,/\}\s*(#.*)?$/' | grep -P -- 'ip\h+saddr')"
		if grep -Pq -- 'ip\h+saddr\h+127\.0\.0\.0\/8\h+(counter\h+packets\h+\d+\h+bytes\h+\d+\h+)?drop' <<< "$l_ipsaddr" || grep -Pq -- 'ip\h+daddr\h+\!\=\h+127\.0\.0\.1\h+ip\h+saddr\h+127\.0\.0\.1\h+drop' <<< "$l_ipsaddr"; then
			l_ipsaddr_test="passed"
		else
			l_ipsaddr_test="$l_ipsaddr_test\n - IPv4 network traffic from loopback address not set to drop"
		fi

		if grep -Pq -- '^\h*0\h*$' /sys/module/ipv6/parameters/disable; then
			l_ip6saddr="$(nft list ruleset | awk '/filter_IN_public_deny|hook input/,/}/' | grep 'ip6 saddr')"
			if grep -Pq 'ip6\h+saddr\h+::1\h+(counter\h+packets\h+\d+\h+bytes\h+\d+\h+)?drop' <<< "$l_ip6saddr" || grep -Pq -- 'ip6\h+daddr\h+\!=\h+::1\h+ip6\h+saddr\h+::1\h+drop' <<< "$l_ip6saddr"; then
				l_ip6saddr_test="passed"
			else
				l_ip6saddr_test="$l_ip6saddr_test\n - IPv6 network traffic from loopback address not set to drop"
			fi
		fi

		if [ "$l_nft_test" != "passed" ]; then
        	failed_results+="\n - $l_nft_test"
		fi

		if [ "$l_ipsaddr_test" != "passed" ]; then
			failed_results+="\n - $l_ipsaddr_test"
		fi

		if [ "$l_ip6saddr_test" != "passed" ]; then
			failed_results+="\n - $l_ip6saddr_test"
		fi

		if [ -n "$failed_results" ]; then
			echo -e "\n- Audit Result:\n  *** FAIL ***$failed_results" | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure nftables loopback traffic is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		else
			echo -e "\n- Audit Result:\n  *** PASS ***" | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure nftables loopback traffic is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		fi
	}

	fed28_ensure_nftables_loopback_traffic_is_configured_fix()
	{
		echo -e "- Start remediation - Ensure nftables loopback traffic is configured" | tee -a "$LOG" 2>> "$ELOG"
		l_hbfw=""
		if systemctl is-enabled firewalld.service 2>/dev/null| grep -q 'enabled' && systemctl is-enabled nftables.service 2>/dev/null| grep -q 'enabled'; then
			echo -e "\n - Error - Both FirewallD and NFTables are enabled\n - Please follow recommendation: \"Ensure a single firewall configuration utility is in use\""
		elif ! systemctl is-enabled firewalld.service 2>/dev/null| grep -q 'enabled' && ! systemctl is-enabled nftables.service 2>/dev/null| grep -q 'enabled'; then
			echo -e "\n - Error - Neither FirewallD or NFTables is enabled\n - Please follow recommendation: \"Ensure a single firewall configuration utility is in use\""
		else
			if systemctl is-enabled firewalld.service 2>/dev/null| grep -q 'enabled' && ! systemctl is-enabled nftables.service 2>/dev/null| grep -q 'enabled'; then
				echo -e "\n - FirewallD is in use on the system" && l_hbfw="fwd"
			elif ! systemctl is-enabled firewalld.service 2>/dev/null| grep -q 'enabled' && systemctl is-enabled nftables.service 2>/dev/null| grep -q 'enabled'; then
				echo -e "\n - NFTables is in use on the system" && l_hbfw="nft"
			fi
			l_ipsaddr="$(nft list ruleset | awk '/filter_IN_public_deny|hook\s+input\s+/,/\}\s*(#.*)?$/' | grep -P -- 'ip\h+saddr')"
			if ! nft list ruleset | awk '/hook\s+input\s+/,/\}\s*(#.*)?$/' | grep -Pq -- '\H+\h+"lo"\h+accept'; then
				echo -e "\n - Enabling input to accept for loopback address"
				if [ "$l_hbfw" = "fwd" ]; then
					firewall-cmd --permanent --zone=trusted --add-interface=lo
					firewall-cmd --reload
				elif [ "$l_hbfw" = "nft" ]; then
					nft add rule ip filter INPUT iif lo accept
				fi
			fi
			if ! grep -Pq -- 'ip\h+saddr\h+127\.0\.0\.0\/8\h+(counter\h+packets\h+\d+\h+bytes\h+\d+\h+)?drop' <<< "$l_ipsaddr" && ! grep -Pq -- 'ip\h+daddr\h+\!\=\h+127\.0\.0\.1\h+ip\h+saddr\h+127\.0\.0\.1\h+drop' <<< "$l_ipsaddr"; then
				echo -e "\n - Setting IPv4 network traffic from loopback address to drop"
				if [ "$l_hbfw" = "fwd" ]; then
					firewall-cmd --permanent --add-rich-rule='rule family=ipv4 source address="127.0.0.1" destination not address="127.0.0.1" drop'
					firewall-cmd --permanent --zone=trusted --add-rich-rule='rule family=ipv4 source address="127.0.0.1" destination not address="127.0.0.1" drop'
					firewall-cmd --reload
				elif [ "$l_hbfw" = "nft" ]; then
					nft add rule ip filter INPUT ip saddr 127.0.0.0/8 counter drop
				fi
			fi
			if grep -Pq -- '^\h*0\h*$' /sys/module/ipv6/parameters/disable; then
				l_ip6saddr="$(nft list ruleset | awk '/filter_IN_public_deny|hook input/,/}/' | grep 'ip6 saddr')"
				if ! grep -Pq 'ip6\h+saddr\h+::1\h+(counter\h+packets\h+\d+\h+bytes\h+\d+\h+)?drop' <<< "$l_ip6saddr" && ! grep -Pq -- 'ip6\h+daddr\h+\!=\h+::1\h+ip6\h+saddr\h+::1\h+drop' <<< "$l_ip6saddr"; then
					echo -e "\n - Setting IPv6 network traffic from loopback address to drop"
					if [ "$l_hbfw" = "fwd" ]; then
					firewall-cmd --permanent --add-rich-rule='rule family=ipv6 source address="::1" destination not address="::1" drop'
					firewall-cmd --permanent --zone=trusted --add-rich-rule='rule family=ipv6 source address="::1" destination not address="::1" drop'
					firewall-cmd --reload
					elif [ "$l_hbfw" = "nft" ]; then
						nft add rule ip6 filter INPUT ip6 saddr ::1 counter drop
					fi
				fi
			fi
		fi
		echo -e "- End remediation - Ensure nftables loopback traffic is configured" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed28_ensure_nftables_loopback_traffic_is_configured_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed28_ensure_nftables_loopback_traffic_is_configured_fix
		fed28_ensure_nftables_loopback_traffic_is_configured_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}