#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 30055b32
#   function = fed_ensure_audit_backlog_limit_sufficient
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_audit_backlog_limit_sufficient.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       11/03/20    Recommendation "Ensure audit_backlog_limit is sufficient"
# Eric Pinnell       01/14/21    Modified - Updated variable name to correct conflict with a global variable
# David Neilson      08/02/22    Updated to current standards.
# Randie Bejar       11/06/23    updated to new version 

fed_ensure_audit_backlog_limit_sufficient()
{
        # Start recommendation entry for verbose log and output to screen
        echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
        l_test=""

        fed_ensure_audit_backlog_limit_sufficient_chk()
        {
                echo -e "- Start check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
                l_audit_backlog_limit=""

                if grubby --info=ALL | grep -Po "\baudit_backlog_limit=\d+\b"; then
                        l_audit_backlog_limit="passed"
                else
                        l_audit_backlog_limit="failed"
                fi                

                # Determine if the audit_backlog_limit variable exists in the grub file, and if it is >= 8192.
                
                if [ "$l_audit_backlog_limit" = "passed" ]; then
                        echo -e "- PASSED:\n- audit backlog limit is set to a sufficient value" | tee -a "$LOG" 2>> "$ELOG"
                         echo -e "- End check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_PASS:-101}"
                else
                        echo -e "- FAILED:\n- audit backlog limit is NOT set to a sufficiently high value" | tee -a "$LOG" 2>> "$ELOG"
                        echo -e "- End check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_PASS:-102}"
                fi
                
        }

        fed_ensure_audit_backlog_limit_sufficient_fix()
        {
                echo -e "- Start remediation - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
                # Set audit_backlog_limit to 8192
                grubby --update-kernel ALL --args 'audit_backlog_limit=8192'
                echo -e " Verify the audit_backlog_limit is sufficient for the organization" | tee -a "$LOG" 2>> "$ELOG"
              
                echo -e "- End remediation - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
        }

        fed_ensure_audit_backlog_limit_sufficient_chk
        if [ "$?" = "101" ]; then
                [ -z "$l_test" ] && l_test="passed"
        else
                fed_ensure_audit_backlog_limit_sufficient_fix
                fed_ensure_audit_backlog_limit_sufficient_chk
                if [ "$?" = "101" ]; then
                        [ "$l_test" != "failed" ] && l_test="remediated"
                else
                        l_test="failed"
                fi
        fi

        # Set return code, end recommendation entry in verbose log, and return
        case "$l_test" in
                passed)
                        echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_PASS:-101}"
                        ;;
                remediated)
                        echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_PASS:-103}"
                        ;;
                manual)
                        echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_FAIL:-106}"
                        ;;
                NA)
                        echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_PASS:-104}"
                        ;;
                *)
                        echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
                        return "${XCCDF_RESULT_FAIL:-102}"
                        ;;
        esac
}