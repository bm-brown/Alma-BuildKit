#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = c7deceac
#   function = fed_ensure_auditing_processes_start_prior_auditd_enabled
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_auditing_processes_start_prior_auditd_enabled.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       11/03/20    Recommendation "Ensure auditing for processes that start prior to auditd is enabled"
# Eric Pinnell       01/14/21    Modified - Updated variable name to correct conflict with a global variable 
# David Neilson	     07/23/22	 Updated to current standards
# Randie Bejar		 11/06/23	 Updated to new version 

fed_ensure_auditing_processes_start_prior_auditd_enabled()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_auditing_processes_start_prior_auditd_enabled_chk()
	{
		echo -e "- Start check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
		l_test1=""
				
		if grubby --info=ALL | grep -Po '\baudit=1\b'; then
			l_test1="passed"
		else
			l_test1="failed"
		fi	
		
		if [ "$l_test1" = "passed" ]; then
			echo -e "- PASSED:\n- Processes can be audited that start prior to auditd being enabled" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"  
		elif [ "$l_test1" = "failed" ]; then
			echo -e "- FAILED:\n- Processes that start prior to auditd can NOT be audited" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi	
	}

	fed_ensure_auditing_processes_start_prior_auditd_enabled_fix()
	{
		echo -e "- Start remediation - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"

		grubby --update-kernel ALL --args 'audit=1'

		echo -e "- End remediation - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed_ensure_auditing_processes_start_prior_auditd_enabled_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test" = "manual" ]; then
		:
	else
		fed_ensure_auditing_processes_start_prior_auditd_enabled_fix
		fed_ensure_auditing_processes_start_prior_auditd_enabled_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}