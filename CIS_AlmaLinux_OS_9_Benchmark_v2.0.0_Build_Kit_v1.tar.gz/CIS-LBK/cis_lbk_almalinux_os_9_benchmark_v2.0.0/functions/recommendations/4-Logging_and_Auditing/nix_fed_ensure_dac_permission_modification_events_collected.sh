#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = a45d2b8d
#   function = fed_ensure_dac_permission_modification_events_collected
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_dac_permission_modification_events_collected.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/05/20    Recommendation "Ensure discretionary access control permission modification events are collected"
# David Neilson	     08/30/22	 Updated to current standards
# David Neilson	     09/14/22    Made minor syntax changes

fed_ensure_dac_permission_modification_events_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32

	# Check UID_MIN for the system
	l_umin=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)
	fed_ensure_dac_permission_modification_events_collected_chk()
	{
		l_test1=""
		l_test1a=""
		l_test2=""
		l_test2a=""
		l_test3=""
		l_test3a=""
		l_test4=""
		l_test4a=""
		l_test5=""
		l_test5a=""
		l_test6=""
		l_test6a=""
		l_test7=""

		# For 64-bit architectures
		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
				l_test1a="passed"
			fi

			# Check rule "-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
        			l_test3="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
        			l_test3a="passed"
			fi

			# Check rule "a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
        			l_test5="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
        			l_test5a="passed"
			fi
		fi

		# For both 32-bit and 64-bit architectures
		# Check rule "-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
        		l_test2="passed"
		fi
		if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
        		l_test2a="passed"
		fi

		# Check rule "-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules ; then
        		l_test4="passed"
		fi
		if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
        		l_test4a="passed"
		fi

		# Check rule "a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
       			l_test6="passed"
		fi
		# Check rule "a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
       			l_test6a="passed"
		fi

		if [ "$l_sysarch" = "b64" ]; then
			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" -a "$l_test4a" = "passed" -a "$l_test5a" = "passed" -a "$l_test6a" = "passed" ]; then
				echo -e "- PASS:\n- ensure discretionary access control permissions modification events are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ]; then
				l_test7="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure discretionary access control permissions modification events are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- discretionary access control permissions modification events are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		else
			if [ "$l_test2" = "passed" -a "$l_test4" = "passed" -a "$l_test6" = "passed" ] && [ "$l_test2a" = "passed" -a "$l_test4a" = "passed" -a "$l_test6a" = "passed" ]; then
				echo -e "- PASS:\n- ensure discretionary access control permissions modification events are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test2" = "passed" -a "$l_test4" = "passed" -a "$l_test6" = "passed" ]; then
				l_test7="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure discretionary access control permissions modification events are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- discretionary access control permissions modification events are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - discretionary access control permissions" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi
	}

	fed_ensure_dac_permission_modification_events_collected_fix()
	{
		echo "- Start remediation - ensure discretionary access control permissions modification events are being collected" | tee -a "$LOG" 2>> "$ELOG"

		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
			fi
		fi

		if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-S\s+(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat),(chmod|fchmod|fchmodat)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
		fi

		if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-S\s+(chown|fchown|fchownat|lchown)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])(chown[, ]|fchown[, ]|fchownat[, ]|lchown[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
		fi

		if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-S\s+(setxattr|lsetxattr|fsetxattr|removexattr|lremovexattr|fremovexattr)\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])(setxattr[, ]|lsetxattr[, ]|fsetxattr[, ]|removexattr[, ]|lremovexattr[, ]|fremovexattr[, ])\s*-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=$l_umin -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/50-perm_mod.rules
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"
	}

	fed_ensure_dac_permission_modification_events_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test7" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"
		l_test="manual"
	else
		fed_ensure_dac_permission_modification_events_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_dac_permission_modification_events_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}