#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 9fa57b8c
#   function = fed_ensure_successful_file_system_mounts_collected
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_successful_file_system_mounts_collected.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/01/20    Recommendation "Ensure successful file system mounts are collected"
# David Neilson	     08/31/22	 Updated to current standards
# David Neison	     09/13/22	 Made minor syntax change

fed_ensure_successful_file_system_mounts_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32

	# Check UID_MIN for the system
	l_umin=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)

	fed_ensure_successful_file_system_mounts_collected_chk()
	{
		l_test1=""
		l_test1a=""
		l_test2=""
		l_test2a=""
		l_test3=""

		# For 64-bit architectures
		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k {key name}"
			if grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
				l_test1a="passed"
			fi
		fi

		# Check rule "-a always,exit -F arch=b3264 -S mount -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test2="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b'; then
			l_test2a="passed"
		fi

		if [ "$l_sysarch" = "b64" ]; then
			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" ]; then
				echo -e "- PASS:\n- ensure successful file system mounts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" ]; then
				l_test3="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure successful file system mounts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- successful file system mounts are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		else
			if [ "$l_test2" = "passed" ] && [ "$l_test2a" = "passed" ]; then
				echo -e "- PASS:\n- ensure successful file system mounts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test2" = "passed" ]; then
				l_test3="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure successful file system mounts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- successful file system mounts are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - file system mounts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi
	}

	fed_ensure_successful_file_system_mounts_collected_fix()
	{
		echo "- Start remediation - ensure successful file system mounts are collected" | tee -a "$LOG" 2>> "$ELOG"

		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S mount -F auid>=$l_umin -F auid!=4294967295 -k mounts" >> /etc/audit/rules.d/50-mounts.rules
			fi
		fi

		if ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+mount\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S mount -F auid>=$l_umin -F auid!=4294967295 -k mounts" >> /etc/audit/rules.d/50-mounts.rules
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"
	}

	fed_ensure_successful_file_system_mounts_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test3" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"
		l_test="manual"
	else
		fed_ensure_successful_file_system_mounts_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_successful_file_system_mounts_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}