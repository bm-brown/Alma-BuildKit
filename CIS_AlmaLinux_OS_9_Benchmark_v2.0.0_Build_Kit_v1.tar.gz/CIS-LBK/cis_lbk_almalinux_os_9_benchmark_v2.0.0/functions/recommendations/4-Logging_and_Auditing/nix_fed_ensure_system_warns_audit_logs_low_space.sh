#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 219235c7
#   function = fed_ensure_system_warns_audit_logs_low_space
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_system_warns_audit_logs_low_space.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar       10/13/23    Recommendation "Ensure system warns when audit logs are low on space"
#

fed_ensure_system_warns_audit_logs_low_space()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - Ensure system warns when audit logs are low on space \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_system_warns_audit_logs_low_space_chk()
	{
		l_test1=""
		l_test2=""
			

		# Check space_left_action
		if grep -Eqs '^\s*space_left_action\s*=\s*email\b' /etc/audit/auditd.conf; then
			l_test1=passed
		fi

		
		# Check admin_space_left_action
		if grep -Eqs '^\s*admin_space_left_action\s*=\s*(halt|single)\b' /etc/audit/auditd.conf; then
			l_test2=passed
		fi
		
		if  [ "$l_test1" = "passed" ] && [ "$l_test2" = "passed" ]; then
			echo -e "- PASS:\n- system warns when audit logs are low on space"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - Ensure system warns when audit logs are low on space" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED: system does NOT warn when audit logs are low on space" | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - Ensure system warns when audit logs are low on space" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}

	fed_ensure_system_warns_audit_logs_low_space_fix()
	{
		echo "- Start remediation - Ensure system warns when audit logs are low on space" | tee -a "$LOG" 2>> "$ELOG"
		# Setting space_left_action parameter in /etc/audit/auditd.conf to email
        if [ -z "$l_test1" ]; then
			if grep -Eqs '^\s*(#*\s*)?space_left_action\s*=\s*' /etc/audit/auditd.conf; then
				sed -ri 's/^\s*(#*\s*)?(space_left_action\s*=\s*)(\S+\s*)?(.*)$/\2email \4/' /etc/audit/auditd.conf
			else
				echo "space_left_action = email" >> /etc/audit/auditd.conf
			fi
		fi	

		# Setting admin_space_left_action parameter in /etc/audit/auditd.conf to halt
		if [ -z "$l_test2" ]; then
			if grep -Eqs '\s*(#*\s*)?admin_space_left_action\s*=\s*' /etc/audit/auditd.conf; then
				sed -ri 's/\s*(#*\s*)?(admin_space_left_action\s*=\s*)(\S+\s*)?(.*)$/\2halt \4/' /etc/audit/auditd.conf
			else
				echo "admin_space_left_action = halt" >> /etc/audit/auditd.conf
			fi
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"
	}

	fed_ensure_system_warns_audit_logs_low_space_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_system_warns_audit_logs_low_space_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_system_warns_audit_logs_low_space_chk
		if [ "$?" != "101" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	
}