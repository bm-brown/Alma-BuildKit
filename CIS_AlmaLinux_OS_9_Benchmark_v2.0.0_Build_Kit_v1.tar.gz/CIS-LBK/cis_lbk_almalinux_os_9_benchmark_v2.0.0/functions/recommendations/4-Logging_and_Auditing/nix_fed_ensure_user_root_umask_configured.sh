#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 9d436a62
#   function = fed_ensure_user_root_umask_configured
#   applicable =
# # END METADATA
#
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_user_root_umask_configured.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Randie Bejar       11/07/23    Recommendation "Ensure root user umask is configured"
#
fed_ensure_user_root_umask_configured()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - Ensure root user umask is configured \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed_ensure_user_root_umask_configured_chk()
    {
        echo -e "- Start check - Ensure root user umask is configured" | tee -a "$LOG" 2>> "$ELOG"
        l_output="" l_output2=""

        if grep -Psi -- '^\h*umask\h+(([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0-6]\b)|([0-7][01][0-7]\b|[0-7][0-7][0-6]\b)|(u=[rwx]{1,3},)?(((g=[rx]?[rx]?w[rx]?[rx]?\b)(,o=[rwx]{1,3})?)|((g=[wrx]{1,3},)?o=[wrx]{1,3}\b)))' /root/.bash_profile /root/.bashrc; then
            l_output2="$l_output2\n - root user umask is NOT configured correctly"
        else
            l_output="$l_output\n - root user umask is configured correctly"
        fi    

        if [ -z "$l_output2" ]; then     
            echo -e "- PASS: root user umask is configured correctly" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure root user umask is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAIL:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure root user umask is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        fi
    }

    fed_ensure_user_root_umask_configured_fix()
    {
        echo -e "- Start Remediation - Ensure root user umask is configured" | tee -a "$LOG" 2>> "$ELOG"
         l_failed_locations=$(grep -Pn -- '^\h*umask\h+(([0-7][0-7][01][0-7]\b|[0-7][0-7][0-7][0-6]\b)|([0-7][01][0-7]\b|[0-7][0-7][0-6]\b)|(u=[rwx]{1,3},)?(((g=[rx]?[rx]?w[rx]?[rx]?\b)(,o=[rwx]{1,3})?)|((g=[wrx]{1,3},)?o=[wrx]{1,3}\b)))' /root/.bash_profile /root/.bashrc)

        if [ -n "$l_failed_locations" ]; then
            echo -e "Fixing umask configuration in the following location(s):$l_failed_locations" | tee -a "$LOG" 2>> "$ELOG"
            sed -i '/^\h*umask/s/.*/# &/' /root/.bash_profile /root/.bashrc  # Comment out existing umask lines
            echo -e "umask 0027" >> /root/.bashrc  # Add umask 0027 line to the .bashrc file
            echo -e "umask 0027" >> /root/.bash_profile  # Add umask 0027 line to the .bash_profile file
        fi
    }

    fed_ensure_user_root_umask_configured_chk
        if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
        fed_ensure_user_root_umask_configured_fix
        fed_ensure_user_root_umask_configured_chk
        if [ "$?" = "101" ]; then
            [ "$l_test" != "failed" ] && l_test="remediated"
        else
			l_test="failed"                  
        fi
    fi

    # Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac   
      
}