#!/usr/bin/env bash
#
# # START METADATA
#   recommendation = 692fe3f9
#   function = ensure_no_files_or_dirs_without_owner_and_group_exist
#   applicable =
# # END METADATA
#
#
#
#
# CIS-LBK _Main Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_no_files_or_dirs_without_owner_and_group_exist.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# J Brown             04/21/24    Recommendation "Ensure no files or directories without an owner and a group exist"
#

ensure_no_files_or_dirs_without_owner_and_group_exist()
{
    # Checks for ungrouped files
    echo -e "- Start check - Ensure no files or directories without an owner and a group exist" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    ensure_no_files_or_dirs_without_owner_and_group_exist_chk()
    {
        l_output="" l_output2=""
        a_nouser=(); a_nogroup=() # Initialize arrays

        a_path=(! -path "/run/user/*" -a ! -path "/proc/*" -a ! -path "*/containerd/*" -a ! -path "*/kubelet/pods/*" -a ! -path "*/kubelet/plugins/*" -a ! -path "/sys/fs/cgroup/memory/*" -a ! -path "/var/*/private/*")

        while IFS= read -r l_mount; do
            while IFS= read -r -d $'\0' l_file; do
                if [ -e "$l_file" ]; then
                    while IFS=: read -r l_user l_group; do
                        [ "$l_user" = "UNKNOWN" ] && a_nouser+=("$l_file")
                        [ "$l_group" = "UNKNOWN" ] && a_nogroup+=("$l_file")
                    done < <(stat -Lc '%U:%G' "$l_file")
                fi
            done < <(find "$l_mount" -xdev \( "${a_path[@]}" \) \( -type f -o -type d \) \( -nouser -o -nogroup \) -print0 2> /dev/null)
        done < <(findmnt -Dkerno fstype,target | awk '($1 !~ /^\s*(nfs|proc|smb|vfat|iso9660|efivarfs|selinuxfs)/ && $2 !~ /^\/run\/user\//){print $2}')

        if ! (( ${#a_nouser[@]} > 0 )); then
            l_output="$l_output\n  - No files or directories without a owner exist on the local filesystem."
        else
            l_output2="$l_output2\n  - There are \"$(printf '%s' "${#a_nouser[@]}")\" unowned files or directories on the system.\n   - The following is a list of unowned files and/or directories:\n$(printf '%s\n' "${a_nouser[@]}")\n   - end of list"
        fi

        if ! (( ${#a_nogroup[@]} > 0 )); then
            l_output="$l_output\n  - No files or directories without a group exist on the local filesystem."
        else
            l_output2="$l_output2\n  - There are \"$(printf '%s' "${#a_nogroup[@]}")\" ungrouped files or directories on the system.\n   - The following is a list of ungrouped files and/or directories:\n$(printf '%s\n' "${a_nogroup[@]}")\n   - end of list"
        fi

        unset a_path; unset a_arr ; unset a_nouser; unset a_nogroup # Remove arrays

        if [ -z "$l_output2" ]; then # If l_output2 is empty, we pass
            echo -e "\n- Audit Result:\n  ** PASS **\n - * Correctly configured * :\n$l_output\n"
            echo -e "- End check - Ensure no files or directories without an owner and a group exist" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "\n- Audit Result:\n  ** FAIL **\n - * Reasons for audit failure * :\n$l_output2"
            [ -n "$l_output" ] && echo -e "\n- * Correctly configured * :\n$l_output\n"
            echo -e "- End check - Ensure no files or directories without an owner and a group exist" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        fi
    }

    ensure_no_files_or_dirs_without_owner_and_group_exist_fix()
    {
        echo -e "- Start remediation - Ensure no files or directories without an owner and a group exist" | tee -a "$LOG" 2>> "$ELOG"

        echo -e "- Making unverified changes to file ownership could have significant unintended consequences or result in outages and unhappy users.\n- Remove or set ownership and group ownership of these files and/or directories to an active user on the system as appropriate and in accordance with site policy." | tee -a "$LOG" 2>> "$ELOG"
        l_test="manual"

        echo -e "- End remediation - Ensure no files or directories without an owner and a group exist" | tee -a "$LOG" 2>> "$ELOG"
    }

    ensure_no_files_or_dirs_without_owner_and_group_exist_chk
    if [ $? -eq 101 ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        if [ "$l_test" != "NA" ]; then
            ensure_no_files_or_dirs_without_owner_and_group_exist_fix
            if [ "$l_test" != "manual" ]; then
                ensure_no_files_or_dirs_without_owner_and_group_exist_chk
                if [ $? -eq 101 ]; then
                    [ "$l_test" != "failed" ] && l_test="remediated"
                else
                    l_test="failed"
                fi
            fi
        fi
    fi

    # Set return code, end recommendation entry in verbose log, and return
    case "$l_test" in
        passed)
            echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
            ;;
        remediated)
            echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-103}"
            ;;
        manual)
            echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-106}"
            ;;
        NA)
            echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-104}"
            ;;
        *)
            echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
            ;;
    esac
}